# WasherMatch v2

A job-based pressure washer recommendation site designed for affiliate monetization.

## What changed
- Replaced placeholder seed machines with a real initial catalog of 9 current retailer listings.
- Added PSI + GPM + Cleaning Units scoring.
- Added job-specific performance targets.
- Added duty-cycle/frequency matching.
- Added budget penalties for over-budget machines.
- Added transparent explanations for every recommendation.
- Added retailer attribution and affiliate-ready links.
- Added a 5-product shortlist with expandable full results.

## Before launch
1. Verify every product specification and price.
2. Apply to affiliate programs and replace retailerUrl with approved affiliate URLs.
3. Add compliant product images or licensed image URLs.
4. Expand the catalog to 30–100+ verified products.
5. Add analytics and conversion tracking.
6. Add legal business/contact information and finalize privacy/terms.
7. Deploy to a domain and submit sitemap.

## Run locally
npm install
npm run dev

## Build
npm run build
